# Data Package: Hamilton Guild Dynamics — Szafranski Meeting 2026-05-12
Keisuke Nishioka, NIFE/IKM, Leibniz University Hannover

## Contents

### dieckow_observed/
- dieckow_observed_guilds_10pat_3wk.csv
  10 patients (A-L) × 3 weeks × 10 class-level guilds.
  Relative abundances (0-1), community_type column (CT1/CT2, GMM clustering).
  Source: Dieckow et al. 2024, npj Biofilms Microbiomes 10:85.

- guild_matrix_raw_pct.csv
  Same data, percentage format (0-100%), sample IDs as "patient_week".

### szafranski_clinical/
- szafranski2025_peri-implant_5genera_N127.csv
  N=127 cross-sectional peri-implant samples. 5 genera relative abundances
  (An, Fn, Pg, So, Vei) + diagnosis (Health/Mucositis/Peri-implantitis).
  Source: Szafranski et al. 2025 preprint; Joshi et al. 2025, mSystems.

- guild_dysbiosis_index_N127.csv
  Same N=127 samples with equilibrium fractions (Hamilton ODE integration,
  AGORA W=1.0 A matrix) and Guild Dysbiosis Index (GDI).
  GDI = log(dysbiotic guilds / commensal guilds) at equilibrium.

### correspondence/
- reply_szafranski_20260512.docx  Full written reply to the meeting summary.

### reports/
- dieckow_report_EN.pdf  Full analysis report (methods, LOO-CV results, figures).
- progress_report_hamilton_kegg.pdf  Slide-format progress report.

## Key numbers (Hamilton + AGORA W=1.0, LOO-CV)
- LOO-RMSE: 0.0504 (vs gLV free 0.0588, -14%)
- LOO Bray-Curtis: 0.147 (vs persistence null 0.281, -48%)
- Sign agreement: 100% (70/70 constrained pairs)
- External validation (N=127): Kruskal-Wallis p<0.0001, Spearman rho=0.37

## Notes on multivariate analysis
- For Bray-Curtis + PCoA: use the relative abundance columns directly.
- For PERMANOVA in R/vegan: feature table = abundances, metadata = diagnosis/CT columns.
- The 5-genera clinical data maps: So=Streptococcus, An=Actinomyces,
  Vei=Veillonella, Fn=Fusobacterium, Pg=Porphyromonas.
