
## Added in v2

### intermediate/
- intermediate_data_sheet.xlsx
  5-sheet Excel workbook showing the full transformation pipeline:
    README   — sheet descriptions
    1_A_matrix   — fitted 10×10 guild interaction matrix A (symmetric)
    2_b_vectors  — per-patient intrinsic growth rates b_i (10 patients × 10 guilds)
    3_obs_vs_pred — observed (wk1 input) vs LOO-predicted (wk2, wk3) compositions
    4_sign_prior  — metabolic sign constraints from eHOMD/Szafrański experimental data
    5_LOO_summary — per-patient LOO-RMSE (mean = 0.0504)

### scripts/
- loo_cv_dieckow.py     Leave-one-patient-out cross-validation (main analysis script)
- compute_di_szafranski.py  Guild Dysbiosis Index computation for peri-implant cohort

  Requirements: Python >=3.10, jax, numpy, scipy, pandas
  Data paths are relative to the nife/ repository root.
